<?php
define('ROOT','/PROJET SITE WEB MASSON')
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Animalia</title>
    <link rel="stylesheet" href="<?=ROOT?>/css/ntr.css">
</head>
<header>
    <h1>
        <img src="<?=ROOT?>/images/logo.png" alt="logo">
</h1>
<h2>
    <a href="<?=ROOT?>/index.php">Animalia</a>
</h2>
    <form action="" method="get">
            <input type="search" name="recherche" id="recherche" maxlength="200" placeholder="Recherche ...">
            <input type="image" src="">
        </form>
</header>

<body>
 <nav>
    <a href="<?=ROOT?>/php/races.php">Races</a>
    <br>
    <a href="<?=ROOT?>/php/connexion.php">Ajout</a>
 </nav>