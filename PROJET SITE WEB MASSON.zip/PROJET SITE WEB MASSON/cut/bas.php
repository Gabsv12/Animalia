
<footer>

    &copy; copyright

</footer>
</body>
</html>