<?php
define('SERVER', 'mysql:server=localhost; dbname=Animalia');
define('USER','root');
define('PASS','');

$cle = new PDO(SERVER, USER, PASS);