let images = document.querySelectorAll('aside article img');

for (let i = 0; i < images.length; i++) {
  images[i].addEventListener('click', function () {
    let source = this.getAttribute('src');

    // Créer le fond zoom
    let div = document.createElement('div');
    div.setAttribute('id', "zoomies");

    // Créer l'image zoomée
    let nouvelleimg = document.createElement('img');
    nouvelleimg.setAttribute('src', source);

    // Créer la croix pour fermer
    let closeButton = document.createElement('span');
    closeButton.innerHTML = '&times;';

    closeButton.addEventListener('click', function () {
      document.body.removeChild(div);
    });

    // Fermer en cliquant en dehors de l'image
    div.addEventListener('click', function (e) {
      if (e.target === div) {
        document.body.removeChild(div);
      }
    });

    // Ajouter l'image et la croix au div
    div.appendChild(closeButton);
    div.appendChild(nouvelleimg);

    // Ajouter le div au body
    document.body.appendChild(div);
  });
}
