CREATE DATABASE IF NOT EXISTS Animalia;
USE Animalia;

CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom varchar(200) NOT NULL
);

CREATE TABLE animaux (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom varchar(200) NOT NULL,
    race varchar(100) NOT NULL,
    age INT NOT NULL,
    description varchar(300) NOT NULL,
    id_categorie INT NOT NULL,
    FOREIGN KEY (id_categorie) REFERENCES categories(id)
);

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user varchar(200) NOT NULL,
    password VARCHAR(200) NOT NULL
);
