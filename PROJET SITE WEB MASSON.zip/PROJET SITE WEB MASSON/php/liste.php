<?php include '../cut/haut.php'; ?>
<main>
<h4>Ajouter des animaux</h4>
<form action="ajout.php" method="POST">
                    <input type="text" name="nom"  placeholder="nom">
                    <input type="text" name="race" placeholder="race">
                    <input type="number" name="age"  placeholder="age">
                    <input type="text" name="description"  placeholder="description">
                    <article>
                    <input type="submit" placeholder="ajouter">
                    </article>
                </form>
<br>
    <h3>Liste des animaux</h3>

   <table>
    <thead>
        <tr>
         <th>Nom</th>
         <th>Race</th>
         <th>Age</th>
         <th>Description</th>
         <th>Modifier</th>
         <th>Supprimer</th>
        </tr>
    </thead>
    <tbody>

    <?php
    $sql ="SELECT * FROM animaux";

    include '../cut/cle.php';

    $reponse = $cle->query($sql);
    
    foreach($reponse AS $r): ?>

        <tr>
            <td><?= $r['nom']?></td>
            <td><?= $r['race']?></td>
            <td><?= $r['age']?></td>
            <td><?= $r['description']?></td>
            <td>
                <form action="modification.php" method="POST">
                    <input type="hidden" name="id" value="<?= $r['id'] ?>">
                    <article>
                    <input type="image" src="<?=ROOT?>/images/modification.png" alt="modification">
                    </article>
                </form>
            </td>
            <td>
                <form action="suppression.php" method="POST">
                    <input type="hidden" name="id" value="<?= $r['id'] ?>">
                    <article>
                    <input type="image" src="<?=ROOT?>/images/suppression.jpg" alt="suppression">
                    </article>
                </form>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
   </table>
</main>


    <?php include '../cut/bas.php'; 