<?php include "../cut/haut.php"; ?>

<main>

    <h2>Connexion</h2>

    <form action="<?=ROOT?>/php/traitement.php" method="post">

        <input type="text" maxlength="200" placeholder="Identifiant" name="id" id="id">

        <input type="text" maxlength="20" placeholder="Mot de passe" name="MDP" id="MDP">

        <input type="submit" value="S'identifier">

    </form>
</main>

<?php include '../cut/bas.php';