<?php include "../cut/haut.php"; ?>

<main>
<h1>Les chiens</h1>
<br>
<h3>Berger Allemand</h3>
<p>Le Berger Allemand est une race de chien connue pour son intelligence, sa loyauté et sa grande capacité d’apprentissage. Utilisé souvent dans les forces de l’ordre ou comme chien de travail, il est également un excellent compagnon familial. Il possède un pelage dense, généralement noir et feu, et une silhouette élancée et musclée.</p>

<h3>Bulldog</h3>
<p>Le Bulldog, avec son allure trapue, son visage plissé et sa mâchoire imposante, est un chien très affectueux malgré son air bougon. Il est calme, fidèle et s’adapte bien à la vie en appartement. Son tempérament doux en fait un très bon chien de compagnie, notamment pour les enfants.</p>

<h3>Labrador Retriever</h3>
<p>Le Labrador est l’un des chiens les plus populaires au monde, et ce n’est pas un hasard. Il est joueur, sociable, affectueux et facile à éduquer. Il adore l’eau, les promenades et les jeux de balle. Son pelage court peut être noir, chocolat ou jaune. Il est souvent utilisé comme chien guide pour les personnes malvoyantes.</p>

<h1>Les chats</h1>
<br>
<h3>Siamois</h3>
<p>Le Siamois est un chat élégant, au corps élancé, aux yeux bleu vif et au pelage court avec des extrémités plus foncées (oreilles, museau, pattes et queue). Il est très expressif, parfois bavard, et aime beaucoup interagir avec les humains. C’est un chat vif, curieux et très attaché à son maître.</p>

<h3>British Shorthair</h3>
<p>Reconnaissable à son pelage dense et doux, ainsi qu’à sa tête ronde et ses grands yeux expressifs, le British Shorthair est un chat calme, posé et indépendant. Il est affectueux sans être collant et s’adapte bien à la vie en intérieur. Sa robe la plus connue est la "bleu-gris", mais elle existe en de nombreuses couleurs.</p>

<h3>Maine Coon</h3>
<p>Le Maine Coon est l’un des plus grands chats domestiques. Il possède une fourrure longue et épaisse, une queue en panache et des oreilles parfois touffues. Malgré sa taille impressionnante, c’est un géant doux, très sociable et joueur. Il est aussi très apprécié pour sa bonne entente avec les enfants et les autres animaux.<p>
</main>
   
   <aside>
      <article>
       <img src="<?=ROOT?>../images/berger.jpg" alt="chiens berger allemand">
       <p>Berger Allemand</p>
       <img src="<?=ROOT?>../images/bulldog.jpg" alt="chiens bulldog">
       <p>Bulldog</p>
       <img src="<?=ROOT?>../images/lab.jpg" alt="chiens labrador">
       <p>Labrabdor</p>
      </article>
      <article>
       <img src="<?=ROOT?>../images/siamois.jpg" alt="chats siamois">
       <p>Siamois</p>
       <img src="<?=ROOT?>../images/british.jpg" alt="chats british shorthair">
       <p>British Shorthair</p>
       <img src="<?=ROOT?>../images/maine.jpg" alt="chats maine coon">
       <p>Maine Coon</p>
      </article>
</aside>
<script type="text/javascript" src="<?=ROOT?>/js/lightbox.js"></script>
<?php include '../cut/bas.php';