<?php include "../cut/haut.php"; ?>

<main>
Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ullam animi provident adipisci, reiciendis quas natus repudiandae consequuntur aliquam ratione sint, accusantium molestias eligendi, nemo quam tempora molestiae odio voluptatibus eveniet?
</main>
   
   <aside>
      <article>
       <h1>Nos chiens</h1>
       <img src="<?=ROOT?>../images/berger.jpg" alt="chiens berger allemand">Berger Allemand</a>
       <img src="<?=ROOT?>../images/bulldog.jpg" alt="chiens bulldog">Bulldog</a>
       <img src="<?=ROOT?>../images/lab.jpg" alt="chiens labrador">Labrabdor</a>
      </article>
      <article>
       <h1>Nos chats</h1>
       <img src="<?=ROOT?>../images/siamois.jpg" alt="chats siamois">Siamois</a>
       <img src="<?=ROOT?>../images/british.jpg" alt="chats british shorthair">British Shorthair</a>
       <img src="<?=ROOT?>../images/maine.jpg" alt="chats maine coon">Maine Coon</a>
      </article>
</aside>
<script type="text/javascript" src="<?=ROOT?>/js/lightbox.js"></script>
<?php include '../cut/bas.php';