<?php
if (!empty($_POST['nom']) 
&& (!empty($_POST['race']) 
&& (!empty($_POST['age']) 
&& (!empty($_POST['description']))))){
$nom = $_POST['nom'];
$race = $_POST['race'];
$age = $_POST['age'];
$description = $_POST['description'];

$sql = "INSERT INTO animaux(nom,race,age,description) VALUES ('$nom', '$race','$age','$description')";

include '../cut/cle.php';

$cle->query($sql);

header('Location:liste.php');

} else { 
    header('Location: liste.php');
}
?>