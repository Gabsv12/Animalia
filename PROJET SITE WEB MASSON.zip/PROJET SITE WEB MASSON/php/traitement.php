<?php
if (
    (isset($_POST['id']) && $_POST['id'] === "ta" && isset($_POST['MDP']) && $_POST['MDP'] === "dang") ||
    (isset($_POST['id']) && $_POST['id'] === "vidha" && isset($_POST['MDP']) && $_POST['MDP'] === "arthus") ||
    (isset($_POST['id']) && $_POST['id'] === "villa" && isset($_POST['MDP']) && $_POST['MDP'] === "gabriel")
) {
    header('Location: liste.php');
    exit();
} else {
    header('Location: connexion.php');
    exit();
}
?>
