<?php 

if(isset($_POST['id'])){
    $x = $_POST['id'];

    $sql = "DELETE FROM animaux WHERE id=$x";

    include '../cut/cle.php';

    if($cle->query($sql)){
            header('Location:liste.php');
    }
} else {
    header('Location:liste.php');
}