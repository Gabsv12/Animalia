<?php


if(isset($_POST['nom'])){
    $nom = htmlspecialchars($_POST['nom']);
    $race = htmlspecialchars($_POST['race']);
    $age = htmlspecialchars($_POST['age']);
    $description = htmlspecialchars($_POST['description']);
    $id = htmlspecialchars($_POST['id']);
    
    include '../cut/cle.php';
    
    $sql = "UPDATE animaux
    SET nom='$nom', race='$race', age='$age', description='$description'
    WHERE id=$id";

    if($cle->query($sql)){
        header('Location:liste.php');
    }
}
