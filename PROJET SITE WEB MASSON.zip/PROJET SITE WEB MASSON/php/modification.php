<?php 

$id = $_POST['id'];

include '../cut/cle.php';
$sql = "SELECT * FROM animaux WHERE id=$id";

$reponse = $cle->query($sql);

foreach($reponse AS $r): ?>


<form action="update.php" method="POST">
    <input type="text" name="nom" id="nom" value="<?= $r['nom'] ?>" maxlength="200">
    <input type="text" name="race" id="race" value="<?= $r['race'] ?>" maxlength="200">
    <input type="text" name="age" id="age" value="<?= $r['age'] ?>" maxlength="200">
    <input type="text" name="description" id="description" value="<?= $r['description'] ?>" maxlenght="200">
    <input type="hidden" name="id" value="<?= $r['id'] ?>">
    <input type="submit" value="Modifier">
</form>

<?php endforeach; ?>